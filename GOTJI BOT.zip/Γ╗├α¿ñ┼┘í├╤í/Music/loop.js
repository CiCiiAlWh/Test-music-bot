////////////////////////////
//////CONFIG LOAD///////////
////////////////////////////
const { canModifyQueue } = require("../util/MilratoUtil");
const { MessageEmbed } = require("discord.js");
const { attentionembed } = require("../util/attentionembed"); 
const { TOKEN, PREFIX} = require(`../config.js`);
////////////////////////////
//////COMMAND BEGIN/////////
////////////////////////////
module.exports = {
  name: "loop",
  aliases: ['l'],
  description: "สลับลูปเพลง",
  cooldown: 3,
  edesc: `สลับลูปเพลง`,
async execute(message) {
    //if not in a Guild return
    if(!message.guild) return;
    //Get the current Queue
    const queue = message.client.queue.get(message.guild.id);
    //If no Queue Error
    if (!queue) return attentionembed(message, "ไม่มีเพลงที่เล่นอยู่ค้าบ🥺").catch(console.error);
    //If not in a VOICE 
    if (!await canModifyQueue(message.member)) return;
    //Reverse the Loop state
    queue.loop = !queue.loop;
    //Define the Loop embed
    const loopembed = new MessageEmbed()
    .setColor(queue.loop ? "#c219d8" : "#ff0e7a")
    .setAuthor(`วนลูปอยู่ตอนนี้ ${queue.loop ? " เปิดloopอยู่✅" : " ปิดloopอยู่❌"}`, "https://cdn.discordapp.com/emojis/769913064194834511.png")
    //react with approve emoji
    message.react("✅");
    //send message into the Queue chat
    return queue.textChannel
      .send(loopembed)
      .catch(console.error);
  }
};
