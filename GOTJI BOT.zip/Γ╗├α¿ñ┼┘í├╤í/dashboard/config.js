module.exports = {
    "clientId": "875904553994846228",
    "clientSecret": process.env.clientSecret,
    "scopes": ["identify", "guilds"], //เรายังงอยู่ว่าทำไม css มันไม่มา ลองไปเรื่อยๆ เด่วก็หาเจอเอง 555
    "redirectUri": "https://jigot-music.sakdinanth10kvi.repl.co/login/callback"
} //รู้ไหมเราใส่ css ได้ไง 55 ไม่รู้ 555