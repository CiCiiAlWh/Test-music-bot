
module.exports = (app) => {
app.use('/', require('../routers/main'))
app.use('/login', require('../routers/login'))
}