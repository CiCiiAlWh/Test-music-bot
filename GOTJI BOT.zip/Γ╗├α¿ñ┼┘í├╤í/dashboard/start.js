const express = require('express')
const app = express();
const { join } = require('path')
module.exports = function (client) {
let port = 3000;
app.set('port', port);

const session = require('express-session');

app.use(express.static('static'));
app.use(session({
    secret: '48738924783748273742398747238',
    resave: false,
    saveUninitialized: false,
    expires: 31536000315,
}));
app.get('/info', function(req,res) {
  res.send({
    servers: client.guilds.cache.size,
    users: client.guilds.cache.reduce((a, b) => a + b.memberCount, 0),
    channels: client.channels.cache.size
  })
})
app.get('/servers/:id', function(req,res) {
let id = req.params.id
if(!client.guilds.cache.get(id)) return req.res
})
app.get('/user', function(req,res) {
if(!req.session.user) {
  res.send(null)
} else {
  res.send(req.session.user)
}
})
app.get('/servers/list', function(req,res) {
  oauth.getUserGuilds(req.session.user.access_token).then(console.log);
})
app.use("/", require('express').static(join(__dirname, "..", "css")));
app.use("/", require('express').static(join(__dirname, "..", "images")));

app.listen(port, () => {
console.info(require('skyfost-log').log(`Dashboard Start >> ${port}`))
require('./routers')(app)
});
}