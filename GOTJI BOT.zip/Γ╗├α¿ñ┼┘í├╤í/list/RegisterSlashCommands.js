const fs = require("fs");
const path = require("path");
const db = require('quick.db')
/**
 * Register slash commands for a guild
 * @param {require("../structures/DiscordMusicBot")} client
 * @param {string} guild
 */
module.exports = (client, guild) => {
  if(!db.get('premium.'+guild)) return;

  let commandsDir = path.join(__dirname, "..", "others");
  let commandsTwo = path.join(__dirname, "..", "Music");
  fs.readdir(commandsDir, (err, files) => {
    if (err) throw err;
    files.forEach(async (file) => {
      let cmd = require(commandsDir + "/" + file);
      if (!cmd.slash || !cmd.slash.run) return;
      let dataStuff = {
        name: cmd.slash.name,
        description: cmd.slash.description,
        options: cmd.slash.options,
      };

      //Creating variables like this, So you might understand my code :)
      let ClientAPI = client.api.applications(client.user.id);
      let GuildAPI = ClientAPI.guilds(guild);

      try {
        await GuildAPI.commands.post({ data: dataStuff });
      } catch (e) {
        console.log(
          "[Slash Command]: Failed Guild " +
            guild +
            ", Command: " +
            dataStuff.name
        );
      }
    });
  });
    fs.readdir(commandsTwo, (err, files) => {
    if (err) throw err;
    files.forEach(async (file) => {
      let cmd = require(commandsTwo + "/" + file);
      if (!cmd.slash || !cmd.slash.run) return;
      let dataStuff = {
        name: cmd.slash.name,
        description: cmd.slash.description,
        options: cmd.slash.options,
      };

      //Creating variables like this, So you might understand my code :)
      let ClientAPI = client.api.applications(client.user.id);
      let GuildAPI = ClientAPI.guilds(guild);

      try {
        await GuildAPI.commands.post({ data: dataStuff });
      } catch (e) {
        console.log(
          "[Slash Command]: Failed Guild " +
            guild +
            ", Command: " +
            dataStuff.name
        );
      }
    });
  });
};
