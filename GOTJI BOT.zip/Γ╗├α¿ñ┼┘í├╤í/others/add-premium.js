const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);
const db = require('quick.db')
module.exports = {
  name: `premium`,
  description: `ดูคำสั่งทั้งหมดเดี่ยวกับเพลง`,
  aliases: [],
  cooldown: 3,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  async execute(message,args,client) {
if(["806783533505970186","662586839604920333","592649371330543626"].includes(message.author.id)) {
let guildd = client.guilds.cache.get(args[0])
if(!guildd)  {
  message.reply(new MessageEmbed()
.setTitle('🥺กรุณาใส่ไอดีดิสที่ต้องการด้วยค้าบ🥺')
.setColor('white'))
} else {
  if(!db.get('premium.'+message.guild.id)) {
  message.reply(new MessageEmbed()
  .setTitle('กำลังเพิ่ม 📀Premium📀 ให้กับดิส '+guildd.name)
  .setColor('GREEN')).then(msg => {
db.set('premium.'+message.guild.id, true)
msg.edit(new MessageEmbed()
  .setTitle('เพิ่ม 💽Premium💽 ให้กับ '+guildd.name+' แล้ว✅')
  .setColor('GREEN'))
  })
  } else {
     message.reply(new MessageEmbed()
  .setTitle('กำลังเอา Premium ออกกับดิส❌ '+guildd.name)
  .setColor('GREEN')).then(msg => {
db.set('premium.'+message.guild.id, false)
msg.edit(new MessageEmbed()
  .setTitle('เอา Premium ออกให้กับดิส '+guildd.name+' แล้ว✅')
  .setColor('GREEN'))
  }) 
  }
}
} else {}
  }
}