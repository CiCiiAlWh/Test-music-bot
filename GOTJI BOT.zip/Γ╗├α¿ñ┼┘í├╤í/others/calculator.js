const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);

module.exports = {
  name: `calculator`,
  description: `เปิดเครื่องคิดเลข`,
  aliases: ["cal"],
  cooldown: 3,
  premium: true,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  async execute(message,args,client) {
  const Calculator = require('../list/cal.js')
  
    await Calculator({
    embed: {
        title: 'เครื่องคิดเลข | JiGOTmusic Premium',
        color: 'RED',
        footer: 'ใช้งานโดย '+message.author.tag,
        timestamp: true
    },
    disabledQuery: 'เครื่องคิดเลขได้ปิดอยู่!',
    invalidQuery: 'ใส่ให้ถูกตามคิดเลขด้วยนะ!',
    othersMessage: 'เฉพาะ <@{{author}}> ที่จะใช้งานได้!'
}, message);
},
}