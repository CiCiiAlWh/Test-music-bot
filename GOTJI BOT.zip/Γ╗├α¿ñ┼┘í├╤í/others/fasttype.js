const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);
const db = require('quick.db')
const SnakeGame = require('snakecord');

module.exports = {
  name: `fasttype`,
  description: `เล่น Fast Type`,
  aliases: [],
  cooldown: 3,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  premium: true,
  async execute(message,args,client) {
    const { FastType } = require('weky')
await FastType({
    message: message,
    embed: {
        title: 'FastType | JiGOTmusic Premium',
        description: 'เรามีเวลา **{{time}}** เพื่อพิมพ์ให้หมดตรงด้านล่างนี้.⏰',
        color: 'RED',
        footer: 'https://jigot-bot.xyz',
        timestamp: true
    },
    sentence: 'IloveJiGOTmuiscVeryMuch',
    winMessage: 'ชนะแล้วงับคุณสามารถพิมพ์คำว่า **IloveJiGOTmuiscVeryMuch** ได้ในเวลา **{{time}}**.',
    loseMessage: 'อุ้ย แพ้แล้วง่า อีกตาไหมล้าา อิอิ😁',
    cancelMessage: 'หยุดเล่นแล้วงับ!',
    time: 5 * 60000,
    buttonText: 'ยอมแพ้🤍',
    othersMessage: 'เฉพาะ <@{{author}}> ถึงจะใช้ปุ่มได้นะงับ!'
});

  }
}