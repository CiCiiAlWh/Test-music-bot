const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);

module.exports = {
  name: `fight`,
  description: `เล่นต่อสู่`,
  aliases: [],
  cooldown: 3,
  premium: true,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  async execute(message,args,client) {
        if(!message.mentions.users.first()) return message.channel.send(`กรุณาแท็คคนที่จะชวนด้วยน้าค้าา💖`)
    if(message.mentions.users.first() === message.author) return message.channel.send(`โหมดนี้ไม่สามารถเล่นคนเดียวได้น้า กรุณาเล่น 2 คนขึ้นไป ค้าา 😘`)
    if(message.mentions.users.first() === client.user) return message.channel.send(`อุ้ยเขินมีคนชวนเล่นเกม ต่อยมวย ด้วยไม่รับดีกว่า พอดีโหดเกิน 😎`)
        if(message.mentions.users.first().bot) return message.channel.send(`เล่นกับหนู ไม่ได้น้า หนูไม่ว่าง งื้อ 🥺`)
const { Fight } = require('weky')
await Fight({
    message: message,
    opponent: message.mentions.users.first(),
    embed: {
        title: 'Fight | JiGOTmusic Premium',
        color: '#7289da',
        footer: 'https://jigot-bot.xyz',
        timestamp: true
    }, //อืมมมมมมมม ทำต่อละ XD 555 ทำไมมันมีแค่ 3 ปุ่มวะ ปุ่มหมัดหาย 555
    buttons: {
      hit: 'หมัด👊',
      hit: 'ยิง🔫',
      heal: 'พันยา🔋',
      cancel: 'ยกเลิกเกม❌',
      accept: 'รับคำท้า✅',
      deny: 'ไม่รับคำท้า❌'
    },
    acceptMessage: '<@{{challenger}}> ได้ท้า <@{{opponent}}> ให้มาต่อสู่ค้าา 😈',
    winMessage: '<@{{winner}}> คุณชนะในการต่อสู่งับ🏆',
    endMessage: '<@{{opponent}}> หมดเวลาในการต่อสู้ หนูว่านะเขาน่าจะสู้ไม่ไหวแล้ว ปล่อยเขาไปเถอะ 😉',
    cancelMessage: '<@{{opponent}}> ได้หยุดสู่กับคุณแล้วค้าา ❌',
    fightMessage: '{{player}} ต่อยได้เลยค้าา👊',
    opponentsTurnMessage: 'รออีกฝ่ายตอบโต้น้าค้าา 👿',
    highHealthMessage: 'เราไม่สามารถรักษาได้ค้า หาก HP ของเราสูงกว่า 80 น้าค้าา❌',
    lowHealthMessage: 'เราไม่สามารถยกเลิกการต่อสู้ได้หาก HP ของเราต่ำกว่า 50!❌',
    returnWinner: false,
    othersMessage: 'เฉพาะ {{author}} เท่านั้นที่จะกดปุ่มได้นะจ๊ะ'
});

},

}