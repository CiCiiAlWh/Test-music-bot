const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);
const db = require('quick.db')
module.exports = {
  name: `help`,
  description: `ดูคำสั่งทั้งหมด`,
  aliases: ["h-music","commands-music"],
  cooldown: 3,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  execute(message,args,client) {
    let premium = [];
    let commands = message.client.commands.array();
 
    let helpEmbed = new MessageEmbed()
      .setTitle("ช่วยเหลือ")
      .setDescription(`**คำนำหน้า:** \`${PREFIX}\``)
.setFooter(`การร้องขอโดย : ${message.author.tag}`, message.author.displayAvatarURL({size: 4096, dynamic: true }))
      .setColor("#F0EAD6");
      
            commands.forEach((cmd) => {
              if(["premium","un-premium","eval","unblacklist","blacklist"].includes(cmd.name)) {} else {
                if(cmd.premium) {
                premium.push(cmd)
                } else {
              helpEmbed.addField(
                `**${message.client.prefix}${cmd.name}**`,
                `${cmd.description}`,
                true
              );
              }
              }
            });

            if(db.get('premium.'+message.guild.id)) helpEmbed.addField('~~--------------------------------------------------------------------------------------~~', ':white_check_mark:~~-------------~~คำสั่ง Premium งับ         ~~-------------~~:white_check_mark:')
  
            premium.forEach(cmd => {
              if(!db.get('premium.'+message.guild.id)) return;
                helpEmbed.addField(
                `**${message.client.prefix}${cmd.name}**`,
                `${cmd.description}`,
                true
              );
            })
          if(!message.guild) {
            if(!args[0]) {message.react(approveemoji);return message.channel.send(helpEmbed);}
            return
            }
            message.channel.send(helpEmbed);

     

},
 slash: {
   name: "help",
   description: `ดูคำสั่งทั้งหมด`,
   options: [],
   execute: async (client, interaction, args) => {
    let premium = [];
    let commands = client.commands.array();
    let user = client.users.cache.get(interaction.member.user.id)
    let helpEmbed = new MessageEmbed()
      .setTitle("ช่วยเหลือ")
      .setDescription(`**คำนำหน้า:** \`${PREFIX}\``)
.setFooter(`การร้องขอโดย : ${user.tag}`, user.displayAvatarURL({size: 4096, dynamic: true }))
      .setColor("#F0EAD6");
      
            commands.forEach((cmd) => {
              if(["premium","un-premium","eval","unblacklist","blacklist"].includes(cmd.name)) {} else {
                if(cmd.premium) {
                premium.push(cmd)
                } else {
              helpEmbed.addField(
                `**${client.prefix}${cmd.name}**`,
                `${cmd.description}`,
                true
              );
              }
              }
            });

            if(db.get('premium.'+interaction.guild.id)) helpEmbed.addField('~~--------------------------------------------------------------------------------------~~', ':white_check_mark:~~-------------~~คำสั่ง Premium งับ         ~~-------------~~:white_check_mark:')
  
            premium.forEach(cmd => {
              if(!db.get('premium.'+interaction.guild.id)) return;
                helpEmbed.addField(
                `**${client.prefix}${cmd.name}**`,
                `${cmd.description}`,
                true
              );
            })

                         interaction.reply(helpEmbed)
   }
 }
}