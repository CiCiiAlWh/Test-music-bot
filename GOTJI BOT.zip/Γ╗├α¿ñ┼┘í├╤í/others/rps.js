const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);

module.exports = {
  name: `rps`,
  description: `เล่น RPS`,
  aliases: [],
  cooldown: 3,
  premium: true,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  async execute(message,args,client) {
        if(!message.mentions.users.first()) return message.channel.send(`กรุณาแท็คคนที่จะชวนด้วยน้า💖`)
    if(message.mentions.users.first() === message.author) return message.channel.send(`เล่นคนเดียวไม่ได้น้าค้าบ มาเล่นกับหนูมั้ยล้าา 🥺`)
    if(message.mentions.users.first() === client.user) return message.channel.send(`อุ้ยเขินมีคนชวนเล่น RPS ด้วยไม่รับดีกว่าเขิน ❌`)
        if(message.mentions.users.first().bot) return message.channel.send(`หนูยังไม่ว่างง่า หนูกำลังดูแลพี่ก็อดอยู่ ไว้วันหลังน้าค้าบ 😋`)
const { RockPaperScissors } = require('weky'); 
await RockPaperScissors({
	message: message,
	opponent: message.mentions.users.first(),
	embed: {
		title: 'Rock Paper Scissors | JiGOTmusic Premium',
		description: 'กดปุ่มด้านล่างเพื่อเลือกสิ่งที่ต้องการน้า งื้อ 🥺',
		color: '#7289da',
        footer: 'https://jigot-bot.xyz',
		timestamp: true
	},
	buttons: {
		rock: 'Rock',
		paper: 'Paper',
		scissors: 'Scissors',
		accept: 'รับ',
		deny: 'ปฎิเสธ',
	},
	time: 60000,
	acceptMessage:
		'<@{{challenger}}> ได้เชิญ <@{{opponent}}> มาเล่น Rock Paper Scissors จะยอมรับไหมค้าา😝',
	winMessage: '<@{{winner}}> เป็นผู้ชนะในเกมนี้ค้าา 😛',
	drawMessage: 'เสมอกันงับ',
	endMessage: "<@{{opponent}}> งื้อ ทำไมตอบช้าจัง หนูเลยยกเลิกเกม แงง 😢",
	timeEndMessage:
		"ทั้ง 2 ฝั่ง ไม่ได้เลือกอะไรเลย หนูเลยจบเกมให้เลยค้าาา 🙃",
	cancelMessage:
		'<@{{opponent}}> ปฏิเสธที่จะเล่นเกม Rock Paper and Scissors กับเรางับ เสียใจด้วยน้า งื้อ 😓',
	choseMessage: 'คุณเลือก {{emoji}} แล้วค้าาา 😀',
	noChangeMessage: 'ไม่สามารถเปลี่ยนได้น้างับ 😧',
	othersMessage: 'เฉพาะ {{author}} เท่านั้นที่กดได้เท่านั้นน้างับ งื้อ 🥺',
	returnWinner: false
});
},
}