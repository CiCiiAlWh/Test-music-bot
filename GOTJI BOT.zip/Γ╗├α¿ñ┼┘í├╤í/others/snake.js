const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);
const db = require('quick.db')
const SnakeGame = require('snakecord');

module.exports = {
  name: `snake`,
  description: `เล่น Snake`,
  aliases: [],
  cooldown: 3,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  premium: true,
  async execute(message,args,client) {
        const snakeGame = new SnakeGame({

            title: 'เกมส์งู',
         
            color: "GREEN",
         
            timestamp: true,
         
            gameOverTitle: "แย่จุง แพ้แล้วนะ เอาใหม่อีกตาไหมล้าา😅"
         
         })
         return snakeGame.newGame(message);
  }
}