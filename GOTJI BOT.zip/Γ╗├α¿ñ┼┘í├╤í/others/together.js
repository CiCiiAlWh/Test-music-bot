const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);
const db = require('quick.db')
const fetch = require('node-fetch')
const defaultApplications = {
    'youtube':     '755600276941176913', // Note : Thanks to Snowflake thanks to whom I got YouTube ID
    'poker':       '755827207812677713',
    'betrayal':    '773336526917861400',
    'fishing':     '814288819477020702',
    'chessdev':    '832012586023256104', // Note : First package to offer chessDev, any other package offering it will be clearly inspired by it
    'chess':       '832012774040141894', // Note : First package to offer chess, any other package offering it will be clearly inspired by it
    // 'zombsroyale': '519338998791929866'  // Note : First package to offer ZombsRoyake.Io, any other package offering it will be clearly inspired by it, thanks to https://github.com/LilDerp-IsBetter thanks to whom i got the ZombsRoyale.io ID
};

start = async (channel, type) => {
  let applicationID = defaultApplications[type.toLowerCase()];
      fetch(`https://discord.com/api/v7/channels/${channel}/invites`, { 
        method: "POST",
        body: JSON.stringify({
            max_age: 86400,  
            max_uses: 0, 
            target_application_id: applicationID,
            target_type: 2,
            temporary: false,  
            validate: null 
        }), 
        headers: {
            "Authorization": `Bot ${process.env.token}`, 
            "Content-Type": "application/json"  
        }
    })
       

    .then(res => res.json())  
    .then(invite => {
      if(!invite.code) return 'Error: 404'

      return invite
    })
}
module.exports = {
  name: `together`,
  description: `เล่น Together`,
  aliases: [],
  cooldown: 3,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  premium: true,
  async execute(message,args,client) {
        if(message.member.voice.channel) {
if(!args[0]) return message.reply(new MessageEmbed()
.setTitle('คำสั่ง Together ทั้งหมด')
.setDescription(`
${PREFIX}together poker - เล่นเกมส์ Poker Night
${PREFIX}together youtube - ดู Youtube Together
${PREFIX}together chess - เล่นเกมส์ Chess
${PREFIX}together betrayal - เล่นเกมส์ Betrayal
${PREFIX}together fishing - เล่นเกมส์ Fishing
`)
.setColor('GREEN')
.setFooter('Request by: '+message.author.tag)
.setTimestamp())
const channel = message.member.voice.channel
if(args[0] === 'poker') {
    fetch(`https://discord.com/api/v7/channels/${channel.id}/invites`, { 
        method: "POST",
        body: JSON.stringify({
            max_age: 86400,  
            max_uses: 0, 
            target_application_id: "755827207812677713",
            target_type: 2,
            temporary: false,  
            validate: null 
        }), 
        headers: {
            "Authorization": `Bot ${client.token}`, 
            "Content-Type": "application/json"  
        }
    })
       

    .then(res => res.json())  
    .then(invite => {
      if(!invite.code) return;
return message.channel.send(`Poker: https://discord.gg/${invite.code}`);
    })
}
if(args[0] === 'youtube') {
    fetch(`https://discord.com/api/v7/channels/${channel.id}/invites`, { 
        method: "POST",
        body: JSON.stringify({
            max_age: 86400,  
            max_uses: 0, 
            target_application_id: "755600276941176913",
            target_type: 2,
            temporary: false,  
            validate: null 
        }), 
        headers: {
            "Authorization": `Bot ${client.token}`, 
            "Content-Type": "application/json"  
        }
    })
       

    .then(res => res.json())  
    .then(invite => {
      if(!invite.code) return;
return message.channel.send(`Youtube: https://discord.gg/${invite.code}`);
    })
}
if(args[0] === 'chess') {
    fetch(`https://discord.com/api/v7/channels/${channel.id}/invites`, { 
        method: "POST",
        body: JSON.stringify({
            max_age: 86400,  
            max_uses: 0, 
            target_application_id: "832012774040141894",
            target_type: 2,
            temporary: false,  
            validate: null 
        }), 
        headers: {
            "Authorization": `Bot ${client.token}`, 
            "Content-Type": "application/json"  
        }
    })
       

    .then(res => res.json())  
    .then(invite => {
      if(!invite.code) return;
return message.channel.send(`Chess: https://discord.gg/${invite.code}`);
    })
}
if(args[0] === 'betrayal') {
    fetch(`https://discord.com/api/v7/channels/${channel.id}/invites`, { 
        method: "POST",
        body: JSON.stringify({
            max_age: 86400,  
            max_uses: 0, 
            target_application_id: "773336526917861400",
            target_type: 2,
            temporary: false,  
            validate: null 
        }), 
        headers: {
            "Authorization": `Bot ${client.token}`, 
            "Content-Type": "application/json"  
        }
    })
       

    .then(res => res.json())  
    .then(invite => {
      if(!invite.code) return;
return message.channel.send(`Betrayal: https://discord.gg/${invite.code}`);
    })
}
if(args[0] === 'fishing') {
    fetch(`https://discord.com/api/v7/channels/${channel.id}/invites`, { 
        method: "POST",
        body: JSON.stringify({
            max_age: 86400,  
            max_uses: 0, 
            target_application_id: "814288819477020702",
            target_type: 2,
            temporary: false,  
            validate: null 
        }), 
        headers: {
            "Authorization": `Bot ${client.token}`, 
            "Content-Type": "application/json"  
        }
    })
       

    .then(res => res.json())  
    .then(invite => {
      if(!invite.code) return;
return message.channel.send(`Fishing: https://discord.gg/${invite.code}`);
    })
}

} else {
message.channel.send(new MessageEmbed()
.setTitle('กรุณาเข้าช่องก่อนใช้งานนะค้าบบบ!!')
.setColor('RED'))
        }
  }
}