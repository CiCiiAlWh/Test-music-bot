const { Client, Collection, MessageEmbed } = require(`discord.js`);
const { 
  PREFIX, 
} = require(`../config.js`);

module.exports = {
  name: `xo`,
  description: `เล่น XO`,
  aliases: [],
  cooldown: 3,
  premium: true,
  edesc: "ดูคำสั่งทั้งหมดเดี่ยวกับเพลง",
  execute(message,args,client) {
    
    if(!message.mentions.users.first()) return message.channel.send(`กรุณาแท็คคนที่จะชวนด้วยน้าง้าบ💖`)
    if(message.mentions.users.first() === message.author) return message.channel.send(`เล่นคนเดียวไม่ได้น้า 😃`)
    if(message.mentions.users.first() === client.user) return message.channel.send(`อุ้ยเขินมีคนชวนเล่น XO ด้วยไม่รับดีกว่าเขิน 🥰`)
        if(message.mentions.users.first().bot) return message.channel.send(`คุณไม่สามารถเล่นคนเดียวได้น้างับ 😣`)
    const mention = message.mentions.users.first()
    const { tictactoe } = require('easy-games-js')
    const tic = new tictactoe(mention, message)
    tic.init({ PROVIDE_MEMBER: "กรุณาแท็คคนที่จะชวนด้วยงับ🙂", ACCEPT_CHALLENGE: "{user} จะยอมรับในการเล่นไหม? พิมพ์ Yes เพื่อตอบรับงับ⏰", DOESNT_PLAY: "หนูว่านะ {user} ไม่อยากจะเล่น งื้อ 🤧", WICH_SIDE: "**{user}, คุณจะเลือก? พิมพ์ \`End\` เพื่อยอม!**", GAME_OVER: "จบแล้วค้าบ 🤗", END: "end", INACTIVITY: "game ended due to inactivity!", WINNER: "{winner} คือผู้ชนะค้าบ 😗", DRAW: "Its a draw"})

},
 slash: {
   name: "xo",
   description: `เล่น XO`,
   options: [
  {
                name: "user",
                value: "user",
                type: 6,
                required: true,
                description: "ใส่ user ที่จะเล่นด้วย",
  }
  ],
   execute: async (client, interaction, args) => {
   console.log(args)

   }
 }
}