console.log('Runed')
const math = require('mathjs');
const Discord = require(`discord.js`);
const { Client, Collection, MessageEmbed,MessageAttachment } = require(`discord.js`);
const { readdirSync } = require(`fs`);
const fs = require('fs');
const { join } = require(`path`);
const { TOKEN, PREFIX} = require(`./config.js`);
const figlet = require("figlet");
require('@weky/inlinereply');
const client = new Client({ disableMentions: `` , partials: ['MESSAGE', 'CHANNEL', 'REACTION'] });
process.exit();
client.login(process.env.TOKEN);
button = require(
'discord-buttons'
)
const dialogflow = require('@google-cloud/dialogflow');
const uuid = require('uuid');
client.commands = new Collection();
client.prefix = PREFIX;
client.queue = new Map();
client.setMaxListeners(0);
button(client)
const cooldowns = new Collection();
const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, `\\$&`);
const db = require('quick.db')
    const guild =db.get('shards.0.guild')+db.get('shards.1.guild');
    const channel =db.get('shards.0.channels')+db.get('shards.1.channels');
    const user =db.get('shards.0.user')+db.get('shards.1.user');

client.gettext = async (textt) => {
  // A unique identifier for the given session
  const sessionId = uuid.v4();
  projectId = 'stack-chat-9ich'
  
  // Create a new session
  const sessionClient = new dialogflow.SessionsClient({
	  keyFilename: "./stack-chat-9ich-7b8fed82a537.json"
  });
  const sessionPath = sessionClient.projectAgentSessionPath(
    projectId,
    sessionId
  );

  // The text query request.
  const request = {
    session: sessionPath,
    queryInput: {
      text: {
        // The query to send to the dialogflow agent
        text: textt,
        // The language used by the client (en-US)
        languageCode: 'th',
      },
    },
  };

  // Send request and log result
  const responses = await sessionClient.detectIntent(request);
  const result = responses[0].queryResult;
  json = {
    text: result.fulfillmentText,
    query: textt
  }
  return result.fulfillmentText
}
const guilds = require('./guilds.json'); // This path may vary.

let dashboard = require('./dashboard/start.js');

dashboard(client)
client.on('ready', () => {
  client.user.setUsername("JiGOTmusic");

console.log(`${client.user.username} | ${client.guilds.cache.size} Servers | ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} Users`) 
    
    client.guilds.cache.forEach((guild) => {
      require("./list/RegisterSlashCommands")(client, guild.id);
    });
    let index = 0;
    setInterval(() => {
      
		   
		  const arrayOfStatus = [
	    `JiGOTmusic | =help`
    ];

        if(index === arrayOfStatus.length) index = 0;
        const status = arrayOfStatus[index];
        client.user.setActivity(status, { type: "PLAYING" }).catch(console.error);// PLAYING, WATCHING, LISTENING, STREAMING,
        index++;
    }, 5000) //in ms

});

//DO NOT TOUCH
client.on(`warn`, (info) => console.log(info));
//DO NOT TOUCH
client.on(`error`, console.error);
//DO NOT TOUCH
//FOLDERS:
//Admin custommsg data FUN General Music NSFW others
commandFiles = readdirSync(join(__dirname, `Music`)).filter((file) => file.endsWith(`.js`));
for (const file of commandFiles) {
  const command = require(join(__dirname, `Music`, `${file}`));
  client.commands.set(command.name, command);
}
commandFiles = readdirSync(join(__dirname, `others`)).filter((file) => file.endsWith(`.js`));
for (const file of commandFiles) {
  const command = require(join(__dirname, `others`, `${file}`));
  client.commands.set(command.name, command);
}

    const sessionId = uuid.v4();
  projectId = 'stack-chat-9ich'
  
  // Create a new session
  const sessionClient = new dialogflow.SessionsClient({
	  keyFilename: "./stack-chat-9ich-7b8fed82a537.json"
  });
  const sessionPath = sessionClient.projectAgentSessionPath(
    projectId,
    sessionId
  );

//COMMANDS //DO NOT TOUCH
client.on(`message`, async (message) => {
  if (message.author.bot) return;
//command Handler DO NOT TOUCH
 const prefixRegex = new RegExp(`^(<@!?${client.user.id}>|${escapeRegex(PREFIX)})\\s*`);
 if (!prefixRegex.test(message.content)) return;
 const [, matchedPrefix] = message.content.match(prefixRegex);
 const args = message.content.slice(matchedPrefix.length).trim().split(/ +/);
 const commandName = args.shift().toLowerCase();
 const command =
   client.commands.get(commandName) ||
   client.commands.find((cmd) => cmd.aliases && cmd.aliases.includes(commandName));
 if (!command) return;
 if (!cooldowns.has(command.name)) {
   cooldowns.set(command.name, new Collection());
 }
 const now = Date.now();
 const timestamps = cooldowns.get(command.name);
 const cooldownAmount = (command.cooldown || 1) * 1000;
 if(command.premium) {
 if(!db.get('premium.'+message.guild.id)) return message.reply('Owner : ไปซื้อ Premium ก่อนสิจ้ะถึงจะใช้งานคำสั่งนี้ได้')
 }

 if (timestamps.has(message.author.id)) {
   const expirationTime = timestamps.get(message.author.id) + cooldownAmount;
   if (now < expirationTime) {
     const timeLeft = (expirationTime - now) / 1000;
     return message.reply(
      new MessageEmbed().setColor("#30ff91")
      .setTitle(`❌ กรุณารอ \`${timeLeft.toFixed(1)} วินาที\` ก่อนกลับมาใช้ \`${PREFIX}${command.name}\`!`)    
     );
   }
 }
 timestamps.set(message.author.id, now);
 setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);
 try {
   command.execute(message, args, client);
 } catch (error) {
   console.log(error)
   message.reply(`มีข้อผิดพลาดในการรันคำสั่งนั้น.`)
 }


});
function delay(delayInms) {
 return new Promise(resolve => {
   setTimeout(() => {
     resolve(2);
   }, delayInms);
 });
}
