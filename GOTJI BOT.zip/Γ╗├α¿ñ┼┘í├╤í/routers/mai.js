const router = require('express').Router();
const { join } = require("path");

router.get('/', function(req,res) {
res.sendFile(join(__dirname, "..", "pages", "index.html"));
})

router.get('/servers', function(req,res) {
res.sendFile(join(__dirname, "..", "pages", "servers.html"));
})

module.exports = router;